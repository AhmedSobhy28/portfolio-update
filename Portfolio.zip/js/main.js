document.addEventListener("DOMContentLoaded", () => {
    
    // --- 1. Cinematic 4-Second Loader ---
    const loaderBar = document.querySelector('.loader-bar');
    const loaderPercentage = document.querySelector('.loader-percentage');
    let progress = 0;
    
    const interval = setInterval(() => {
        progress += 1;
        loaderBar.style.width = `${progress}%`;
        loaderPercentage.innerText = `${progress}%`;
        
        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                document.getElementById('loader').style.opacity = '0';
                setTimeout(() => {
                    document.getElementById('loader').style.display = 'none';
                    document.getElementById('main-content').style.opacity = '1';
                }, 800);
            }, 400); 
        }
    }, 35); 


    // --- 2. Orbiting Atmosphere Logic ---
    const orbitIcons = document.querySelectorAll('.orbit-icon');
    
    // The animation loop for the orbiting elements
    function animateOrbit() {
        const time = Date.now() * 0.0005; // Adjust speed here
        
        // Dynamic radius based on screen size for responsiveness
        const orbitRadiusX = Math.min(window.innerWidth * 0.4, 450); 
        const orbitRadiusY = Math.min(window.innerWidth * 0.15, 150); // Elliptical height creates 3D depth
        
        orbitIcons.forEach((icon, index) => {
            // Space them out evenly around the circle
            const angle = time + (index / orbitIcons.length) * Math.PI * 2;
            
            // Calculate X and Y on an ellipse
            const x = Math.cos(angle) * orbitRadiusX;
            const y = Math.sin(angle) * orbitRadiusY;
            
            // Apply scale based on Y position to fake 3D depth (smaller when "behind")
            const scale = (y + orbitRadiusY) / (orbitRadiusY * 2) * 0.5 + 0.5; 
            const zIndex = Math.round(scale * 10);
            
            icon.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
            icon.style.zIndex = zIndex;
            
            // Dim elements slightly when they are "behind" the planet
            icon.style.opacity = scale < 0.75 ? 0.4 : 1;
        });
        
        requestAnimationFrame(animateOrbit);
    }
    animateOrbit();


    // --- 3. Three.js Digital Earth Background ---
    const container = document.getElementById('canvas-container');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio); 
    container.appendChild(renderer.domElement);

    // Using SphereGeometry to create the Earth planet shape
    const geometry = new THREE.SphereGeometry(6, 32, 32); 
    
    // Wireframe material to give it that digital/cyber mapping look
    const material = new THREE.MeshBasicMaterial({ 
        color: 0x00E5FF, 
        wireframe: true, 
        transparent: true, 
        opacity: 0.05 
    });
    
    const digitalEarth = new THREE.Mesh(geometry, material);
    scene.add(digitalEarth);
    
    // Add ambient stars/data particles in the background
    const particlesGeo = new THREE.BufferGeometry();
    const particlesCount = 300;
    const posArray = new Float32Array(particlesCount * 3);
    
    for(let i = 0; i < particlesCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 25;
    }
    particlesGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particlesMat = new THREE.PointsMaterial({
        size: 0.02,
        color: 0x64748B,
        transparent: true,
        opacity: 0.3
    });
    const particlesMesh = new THREE.Points(particlesGeo, particlesMat);
    scene.add(particlesMesh);

    camera.position.z = 12;

    // 3D Animation Loop
    function animateThreeJS() {
        requestAnimationFrame(animateThreeJS);
        
        // Earth rotation
        digitalEarth.rotation.y += 0.002;
        digitalEarth.rotation.x = 0.2; // Slight tilt like Earth's axis
        
        // Particle slow rotation
        particlesMesh.rotation.y -= 0.0005;

        renderer.render(scene, camera);
    }
    animateThreeJS();

    // Responsive Canvas Resizing
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
});