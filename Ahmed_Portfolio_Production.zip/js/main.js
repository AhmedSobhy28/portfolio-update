
// Terminal boot sequence effect
console.log('%c Initialize Systems...', 'color: #39FF14; font-weight: bold; background: #000; padding: 5px;');
console.log('%c [OK] Kernel Loaded', 'color: #39FF14; background: #000; padding: 2px;');
console.log('%c [OK] Security protocols active', 'color: #39FF14; background: #000; padding: 2px;');
